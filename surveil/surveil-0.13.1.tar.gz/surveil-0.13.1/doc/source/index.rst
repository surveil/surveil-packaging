
Welcome to Surveil's documentation!
===================================

Table of Contents:

.. toctree::
   :maxdepth: 2

   readme
   project_architecture
   tutorials/index.rst
   webapi/index
   administration/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
