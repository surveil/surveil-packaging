Administration
##############

This section will covers the administration and configuration of the Surveil services.

.. toctree::
   :maxdepth: 1

   surveil_api
   surveil-os-interface

