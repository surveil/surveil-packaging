Tutorials
#########

Using Surveil
-------------

.. toctree::
   :maxdepth: 1

   installing_surveil
   monitoring_a_host_with_passive_checks
   monitoring_with_your_custom_plugin

Contributing
------------

.. toctree::
   :maxdepth: 1

   getting_started
   developing_the_api
   running_the_tests

