


GLOBAL_CONFIG_COLLECTION_NAME = "global_configuration"
