Please have a look to the `development`_ guidline before sumitting a pull request, especially `this`_ part


.. _development: https://alignak.readthedocs.org/en/latest/15_development/index.html
.. _this: https://alignak.readthedocs.org/en/latest/15_development/hackingcode.html#development-rules
