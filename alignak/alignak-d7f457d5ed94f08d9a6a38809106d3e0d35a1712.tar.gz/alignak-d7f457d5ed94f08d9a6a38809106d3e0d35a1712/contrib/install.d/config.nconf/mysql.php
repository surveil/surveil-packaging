<?php
##
## MySQL config
##

#
# Main MySQL connection parameters
#
define('DBHOST', 'localhost');
define('DBNAME', 'nconf');
define('DBUSER', 'nconf');
define('DBPASS', 'dfgdfg');

?>
