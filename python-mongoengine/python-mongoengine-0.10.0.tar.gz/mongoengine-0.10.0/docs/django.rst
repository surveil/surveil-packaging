==============
Django Support
==============

.. note:: Django support has been split from the main MongoEngine
    repository. The *legacy* Django extension may be found bundled with the
    0.9 release of MongoEngine.



Help Wanted!
------------

The MongoEngine team is looking for help contributing and maintaining a new
Django extension for MongoEngine! If you have Django experience and would like
to help contribute to the project, please get in touch on the 
`mailing list <http://groups.google.com/group/mongoengine-users>`_ or by 
simply contributing on
`GitHub <https://github.com/MongoEngine/django-mongoengine>`_.
