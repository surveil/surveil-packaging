<a href='https://travis-ci.org/shinken-monitoring/mod-mongodb'><img src='https://api.travis-ci.org/shinken-monitoring/mod-mongodb.svg?branch=master' alt='Travis Build'></a>
mod-mongodb
===========

Shinken module used by others modules for mongodb connections



Changelog
=========


1.2 (2014/08/25): 
    Add: (from: VicThor) replicatset managment

