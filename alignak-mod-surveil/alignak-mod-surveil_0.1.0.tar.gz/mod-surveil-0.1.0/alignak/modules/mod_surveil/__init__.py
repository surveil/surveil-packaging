__import__('pkg_resources').declare_namespace(__name__)

VERSION='0.1.0'
