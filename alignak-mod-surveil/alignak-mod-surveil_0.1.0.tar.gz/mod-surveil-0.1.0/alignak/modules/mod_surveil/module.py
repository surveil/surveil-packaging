#!/usr/bin/python

# -*- coding: utf-8 -*-

# Copyright (C) 2009-2012:
# Gabes Jean, naparuba@gmail.com
# Gerhard Lausser, Gerhard.Lausser@consol.de
# Gregory Starck, g.starck@gmail.com
# Hartmut Goebel, h.goebel@goebel-consult.de
#
# This file is part of Alignak
#
# Alignak is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Alignak is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Alignak. If not, see <http://www.gnu.org/licenses/>.

"""
This module job is to get configuration data from Surveil
"""

import time

from surveilclient import client as sclient

from alignak.basemodule import BaseModule
from alignak.log import logger

properties = {
    'daemons': ['arbiter'],
    'type': 'surveil',
    'external': False,
    'phases': ['configuration'],
}


def get_instance(mod_conf):
    logger.info("[surveil] Get a surveil config module for plugin %s",
                mod_conf.get_name())
    instance = SurveilConfig(mod_conf)
    return instance


class SurveilConfig(BaseModule):
    def __init__(self, modconf):
        BaseModule.__init__(self, modconf)
        self.surveil_api_url = getattr(modconf, 'surveil_api_url', None)
        self.surveil_auth_url = getattr(modconf, 'surveil_auth_url', None)
        self.surveil_version = getattr(modconf, 'surveil_version', None)
        self.surveil_client = None

    def init(self):
        self.surveil_client = sclient.Client(
            self.surveil_api_url,
            auth_url=self.surveil_auth_url,
            version=self.surveil_version
        )

    # Main function that is called in the CONFIGURATION phase
    def get_objects(self):
        all_objects = {}

        object_types = [
            'hosts',
            'services',
            'commands'
        ]

        for object_type in object_types:
            all_objects[object_type] = []
            objects = self._get_all_objects(object_type)

            for config_object in objects:
                config_object['imported_from'] = 'surveil-config'

                if object_type in ['hosts', 'services']:
                    custom_fields = config_object.pop("custom_fields", {})
                    for field, value in custom_fields.items():
                        config_object[field] = value
                elif object_type == 'timeperiods':
                    custom_fields = config_object.pop("periods", {})
                    for field, value in custom_fields.items():
                        config_object[field] = value
                all_objects[object_type].append(config_object)

        return all_objects

    def _get_all_objects(self, object_type):
        for attempt in range(3):
            try:
                objects_manager = getattr(
                    self.surveil_client.config,
                    object_type,
                )

                list_kwargs = {}
                if object_type in ['hosts', 'services']:
                    list_kwargs['templates'] = True

                return objects_manager.list(**list_kwargs)

            except Exception as exp:
                logger.error(
                    "[surveil-config] Could not get %s objects from Surveil - try %s/3", (object_type, attempt)
                )
                logger.error('[surveil-config]' + str(exp))
                time.sleep(10)
        #TODO: The arbiter should stop completely.
        raise Exception("Could not load config from Surveil")
