<a href='https://travis-ci.org/shinken-monitoring/mod-retention-redis'><img src='https://api.travis-ci.org/shinken-monitoring/mod-retention-redis.svg?branch=master' alt='Travis Build'></a>
mod-retention-redis
===================

Shinken module for saving retention data from schedulers to a redis server
