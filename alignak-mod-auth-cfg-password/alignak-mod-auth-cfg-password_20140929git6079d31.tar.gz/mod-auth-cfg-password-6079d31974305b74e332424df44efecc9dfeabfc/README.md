<a href='https://travis-ci.org/shinken-monitoring/mod-auth-cfg-password'><img src='https://api.travis-ci.org/shinken-monitoring/mod-auth-cfg-password.svg?branch=master' alt='Travis Build'></a>
mod-auth-cfg-password
=====================

Shinken module for UI authentication from simple password for configuration file
