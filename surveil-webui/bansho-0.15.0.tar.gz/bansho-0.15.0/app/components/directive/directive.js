'use strict';

angular.module('bansho.directive', [
    'bansho.actionbar',
    'bansho.host',
    'bansho.hostTree',
    'bansho.service',
    'bansho.table',
    'bansho.tabpanel',
    'bansho.tactical',
    'bansho.title'
]);
