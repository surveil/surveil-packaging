'use strict';

angular.module('bansho.directive', [
    'bansho.actionbar',
    'bansho.textArea',
    'bansho.container',
    'bansho.hostTree',
    'bansho.stateIcon',
    'bansho.table',
    'bansho.tabpanel',
    'bansho.tactical',
    'bansho.title'
]);
