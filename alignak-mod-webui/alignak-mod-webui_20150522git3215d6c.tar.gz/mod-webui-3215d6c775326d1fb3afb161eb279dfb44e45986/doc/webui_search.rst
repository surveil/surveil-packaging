.. _webui_search:



====================
WebUI search syntax 
====================


work in progress

not that we couldn't tell. ;) eh eh

beware the working men and flying tools!
